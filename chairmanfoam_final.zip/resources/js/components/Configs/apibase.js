module.exports = {
    baseurl:'',
    img_baseurl:'/public/images/'
}