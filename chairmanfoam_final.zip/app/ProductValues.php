<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductValues extends Model
{
    protected $table = 'productvalues';
}
