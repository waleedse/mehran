<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AutomaticDiscount extends Model
{
    protected $table = 'automaticdiscounts';
}
