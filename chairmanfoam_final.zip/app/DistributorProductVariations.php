<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DistributorProductVariations extends Model
{
    protected $table = 'distributors_product_variations';
}
