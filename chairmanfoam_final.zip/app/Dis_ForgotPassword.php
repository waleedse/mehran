<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dis_ForgotPassword extends Model
{
    protected $table = 'dis_forgotpasswords';
}
