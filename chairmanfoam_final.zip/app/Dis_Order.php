<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dis_Order extends Model
{
    protected $table = 'dis_orders';
}
