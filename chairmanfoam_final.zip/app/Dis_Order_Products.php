<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dis_Order_Products extends Model
{
    protected $table = 'dis_order_products';
}
