<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dis_Cart extends Model
{
    protected $table = 'dis_carts';
}
