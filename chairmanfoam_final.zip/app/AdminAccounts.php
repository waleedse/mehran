<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdminAccounts extends Model
{
    protected $table = 'admin_accounts';
}
