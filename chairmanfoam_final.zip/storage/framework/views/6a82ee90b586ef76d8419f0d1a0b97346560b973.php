<!DOCTYPE html>
<html lang="en">
<head>


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?></title>
</head>
<body>

<div  style="box-shadow:0px 0px 13px #252525;border-radius:7px;background-color:#ffffff;font-family:sans-serif">
    <h1 class="card-title ml-4" style="color:rgb(68, 68, 68);font-family:sans-serif;text-align:center"><?php echo e($subtitle); ?> </h1>
    <hr style="color:rgb(138, 138, 138)"/>
    <br>
    <br>
    <h5  style="color:rgb(58, 58, 58);font-family:sans-serif;text-align:center">Click on below button to Reset your password.</h5>
    <div style="text-align:center">
       <a href="<?php echo e(url('/')); ?>/<?php echo e($link); ?>"> <button style="width:200px;height:50px;background-color:#17aa30;
    border-radius:1px;text-align:center;border:0px;color:white;font-size:20px;font-weight:600;cursor:pointer;">Reset Password</button></a>
    </div>
<div >
    
</body>
</html><?php /**PATH C:\Users\waleed.ahmed\Downloads\chairmanfoam_live_1.4.5\resources\views/emails/forgotpassword.blade.php ENDPATH**/ ?>